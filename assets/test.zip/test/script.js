// script.js

/**************** Read Flutter-injected & URL Parameters ****************/
const injectedParams = window.flutterQueryParams || {};
const urlParams = window.searchParams || new URLSearchParams(window.location.search);

const config = {
  identifier: injectedParams.identifier
              || urlParams.get('identifier')
              || 'defaultIdentifier',
  lengthOfTest: parseInt(injectedParams.length_of_test)
                || parseInt(urlParams.get('length_of_test'))
                || 3,   // default 3 seconds
  intendedUseDescription: injectedParams.intendedUseDescription
                          || urlParams.get('intendedUseDescription')
                          || 'Welcome to the Custom Active Task Demo. Please follow the instructions below.'
};

/**************** Global Variables & State ****************/
let currentPageIndex = 0;
let pages = [];
let totalPages = 0;

let result = {
  rightHand: {},
  image: null,
  audio: null,
  location: { latitude: null, longitude: null }
};

let testRunning = false;
let testStartTime = 0;
let tapCount = 0;
let samples = [];
let accEvents = [];
let testInterval = null;

/**************** Page Definitions ****************/
function initPages() {
  pages = [
    {
      type: 'intro',
      title: 'Custom Active Task Demo',
      instructions: [
        config.intendedUseDescription,
        `This test will measure your tapping speed using your RIGHT hand for ${config.lengthOfTest} seconds.`
      ]
    },
    { type: 'test', hand: 'RIGHT' },
    {
      type: 'captureImage',
      title: 'Capture Image (Optional)',
      instructions: ['Capture an image using your camera, or skip this step.']
    },
    {
      type: 'recordAudio',
      title: 'Record Audio (Optional)',
      instructions: ['Record an audio clip using your microphone, or skip this step.']
    },
    {
      type: 'captureLocation',
      title: 'Capture Location',
      instructions: ['Allow location access to capture your latitude and longitude (optional).']
    },
    {
      type: 'errorPrompt',
      title: 'Error Test',
      instructions: ['Do you want to throw an error?']
    },
    {
      type: 'completion',
      title: 'Completion',
      instructions: ['Test complete. Thank you!']
    }
  ];
  totalPages = pages.length;
}

/**************** Rendering & Navigation ****************/
function renderPage(index) {
  const page = pages[index];
  let html = `<div class="top-bar d-flex justify-content-between align-items-center">
                <div>Page ${index + 1} of ${totalPages}</div>`;
  if (index > 0) {
    html += `<button id="backButton" class="btn btn-secondary">Back</button>`;
  }
  html += `</div><div class="content">`;

  if (page.type === 'intro') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<div class="card mb-3"><div class="card-body">
               <h5 class="card-title">URL Parameters</h5>
               <pre>${JSON.stringify(Object.fromEntries(urlParams.entries()), null, 2)}</pre>
             </div></div>
             <button id="nextButton" class="btn btn-primary">Next</button>`;
  }
  else if (page.type === 'test') {
    html += `<h2>Tapping Speed Test</h2>
             <div class="progress mb-3">
               <div id="progressBar" class="progress-bar" style="width:0%"></div>
             </div>
             <p>Total Taps: <span id="tapCount">0</span></p>
             <div class="d-flex justify-content-center">
               <button id="rightButton" class="tap-button">Tap</button>
             </div>`;
  }
  else if (page.type === 'captureImage') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<video id="video" autoplay playsinline style="width:100%;max-width:400px;"></video>
             <canvas id="canvas" style="display:none;"></canvas>
             <div class="bottom-bar">
               <button id="captureButton" class="btn btn-primary">Capture</button>
               <button id="skipImage" class="btn btn-secondary ml-2">Skip</button>
             </div>`;
  }
  else if (page.type === 'recordAudio') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<div id="audioControls" class="mb-3">
               <button id="startRecording" class="btn btn-primary">Start Recording</button>
               <button id="stopRecording" class="btn btn-secondary" disabled>Stop Recording</button>
             </div>
             <button id="skipAudio" class="btn btn-secondary">Skip</button>`;
  }
  else if (page.type === 'captureLocation') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<p id="locationStatus">Attempting to get location...</p>
             <button id="locationNextButton" class="btn btn-primary">Next</button>`;
  }
  else if (page.type === 'errorPrompt') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<div class="d-flex justify-content-center">
               <button id="errorYes" class="btn btn-danger mx-2">Yes</button>
               <button id="errorNo" class="btn btn-secondary mx-2">No</button>
             </div>`;
  }
  else if (page.type === 'completion') {
    html += `<h2>${page.title}</h2>`;
    page.instructions.forEach(i => html += `<p>${i}</p>`);
    html += `<p>Submitting results…</p>
             <button id="submitButton" class="btn btn-success">Submit</button>`;
  }

  html += `</div>`;
  document.getElementById('app').innerHTML = html;

  // Event listeners
  if (page.type !== 'intro') {
    const back = document.getElementById('backButton');
    if (back) back.addEventListener('click', prevPage);
  }
  if (page.type === 'intro') {
    document.getElementById('nextButton').addEventListener('click', nextPage);
  }
  if (page.type === 'test') setupTestPage();
  if (page.type === 'captureImage') setupCaptureImage();
  if (page.type === 'recordAudio') setupRecordAudio();
  if (page.type === 'captureLocation') setupCaptureLocation();
  if (page.type === 'errorPrompt') {
    document.getElementById('errorYes').addEventListener('click', throwError);
    document.getElementById('errorNo').addEventListener('click', nextPage);
  }
  if (page.type === 'completion') {
    document.getElementById('submitButton').addEventListener('click', submitResults);
  }
}

function nextPage() {
  if (currentPageIndex < totalPages - 1) {
    currentPageIndex++;
    renderPage(currentPageIndex);
  } else {
    submitResults();
  }
}
function prevPage() {
  if (currentPageIndex > 0) {
    currentPageIndex--;
    renderPage(currentPageIndex);
  }
}

/**************** Test Logic ****************/
function setupTestPage() {
  testRunning = false; tapCount = 0; samples = []; accEvents = [];
  document.getElementById('tapCount').textContent = '0';
  document.getElementById('rightButton').addEventListener('click', e => {
    if (!testRunning) startTest();
    tapCount++;
    document.getElementById('tapCount').textContent = tapCount;
    samples.push({
      locationX: e.clientX,
      locationY: e.clientY,
      buttonIdentifier: '.Right',
      timestamp: Date.now() - testStartTime
    });
  });
}
function startTest() {
  testRunning = true;
  testStartTime = Date.now();
  window.addEventListener('devicemotion', deviceMotionHandler);
  testInterval = setInterval(() => {
    const elapsed = Date.now() - testStartTime;
    const pct = Math.min((elapsed / (config.lengthOfTest * 1000)) * 100, 100);
    document.getElementById('progressBar').style.width = pct + '%';
    if (elapsed >= config.lengthOfTest * 1000) stopTest();
  }, 50);
}
function stopTest() {
  clearInterval(testInterval);
  testRunning = false;
  window.removeEventListener('devicemotion', deviceMotionHandler);
  const btn = document.getElementById('rightButton').getBoundingClientRect();
  result.rightHand = {
    buttonRect: { locationX: btn.left, locationY: btn.top, width: btn.width, height: btn.height },
    stepViewSize: { width: window.innerWidth, height: window.innerHeight },
    samples
  };
  result.rightHandAccData = accEvents;
  setTimeout(nextPage, 500);
}
function deviceMotionHandler(ev) {
  const a = ev.acceleration;
  if (a) accEvents.push({ x: a.x, y: a.y, z: a.z, timestamp: Date.now() - testStartTime });
}

/**************** Capture Image ****************/
function setupCaptureImage() {
  const video = document.getElementById('video');
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => video.srcObject = stream)
    .catch(() => video.parentElement.innerHTML = '<p>Camera not available.</p>');
  document.getElementById('captureButton').addEventListener('click', () => {
    const canvas = document.getElementById('canvas');
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    canvas.toBlob(blob => {
      const reader = new FileReader();
      reader.onloadend = () => {
        result.image = reader.result;
        video.srcObject.getTracks().forEach(t => t.stop());
        nextPage();
      };
      reader.readAsDataURL(blob);
    });
  });
  document.getElementById('skipImage').addEventListener('click', nextPage);
}

/**************** Record Audio ****************/
function setupRecordAudio() {
  let mediaRecorder, audioChunks = [];
  document.getElementById('startRecording').addEventListener('click', () => {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = e => { if (e.data.size) audioChunks.push(e.data); };
      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          result.audio = reader.result;
          stream.getTracks().forEach(t => t.stop());
          nextPage();
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorder.start();
      document.getElementById('stopRecording').disabled = false;
    });
  });
  document.getElementById('stopRecording').addEventListener('click', () => {
    document.getElementById('stopRecording').disabled = true;
    mediaRecorder.stop();
  });
  document.getElementById('skipAudio').addEventListener('click', nextPage);
}

/**************** Capture Location ****************/
function setupCaptureLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      result.location.latitude = pos.coords.latitude;
      result.location.longitude = pos.coords.longitude;
      document.getElementById('locationStatus').textContent =
        `Latitude: ${pos.coords.latitude}, Longitude: ${pos.coords.longitude}`;
    }, () => {
      document.getElementById('locationStatus').textContent = 'Location not available.';
    });
  } else {
    document.getElementById('locationStatus').textContent = 'Geolocation not supported.';
  }
  document.getElementById('locationNextButton').addEventListener('click', nextPage);
}

/**************** Error Prompt ****************/
function throwError() {
  const errJson = JSON.stringify({ error: true });
  window.flutter_inappwebview.callHandler('returnData', errJson);
  setTimeout(() => window.close(), 500);
}

/**************** Submit Results ****************/
function submitResults() {
  const jsonResult = JSON.stringify(result);
  window.flutter_inappwebview.callHandler('returnData', jsonResult);
  setTimeout(() => window.close(), 500);
}


/**************** Initialization ****************/
initPages();
renderPage(currentPageIndex);
